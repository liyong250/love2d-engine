# Dark Theme
## Information
Dark is a theme for [Love Frames](https://github.com/NikolaiResokav/LoveFrames) - GUI library for [LÖVE](http://www.love2d.org).

The color utility still isn't finished.

## Installation
1. Put **Dark** folder into skins/ folder inside Love Frames.
2. Open **init.lua** in root Love Frames folder and set ```loveframes.config["ACTIVESKIN"]``` to ``"Dark"``.

## License
loveframes-dark-theme is licensed under MIT license.

OpenSans-Bold.ttf and OpenSans-Regular.ttf are licensed under [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)